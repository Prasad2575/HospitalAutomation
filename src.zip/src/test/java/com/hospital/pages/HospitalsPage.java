package com.hospital.pages;

public class HospitalsPage {
}
